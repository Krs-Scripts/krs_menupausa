fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'krs_menupausa'
author 'Karos#7804'


client_script {

    'client/*.lua'
}

server_script {
    
    'server/*.lua'
}

shared_script {

    '@es_extended/imports.lua',
    'config.lua'
}

ui_page 'web/karos.html'

files {
    'web/karos.html',
    'web/css/karos.css',
    'web/js/karos.js',
    'web/img/*.png'
}
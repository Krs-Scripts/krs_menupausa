
RegisterNetEvent("krs_pausemenu:escidalgioco", function()
    local playerSource = source
    DropPlayer(playerSource, Config.ExitMessage)
end)
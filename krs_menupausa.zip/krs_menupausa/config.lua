Config = {}


Config.ExitMessage = '[𝗞𝗥𝗦® │ \nBuona giornata!'

Config.Lang = {

    ['job'] = "Lavoro : %s",
    ['cash'] = "Contanti : $",
    ['bank'] = "Banca : $",
    ['info'] = "INFO",
    ['mappa'] = "MAPPA",
    ['impostazioni'] = "IMPOSTAZIONI",
    ['titolo'] = "KRS MENU PAUSA",
    ['disconnetti'] = "DISCONNETTI"
}
var Lang = {}

function ApriMenuPausa() {
  document.querySelector(".background").style.display = "block";
  document.querySelector(".title").style.display = "block";
  document.querySelector(".boxkaros").style.display = "block";
  document.querySelector(".boxkaros2").style.display = "block";
  document.querySelector(".boxkaros3").style.display = "block";
  document.querySelector(".boxkaros4").style.display = "block";
  document.querySelector(".boxkaros5").style.display = "block";

}

window.addEventListener("message", function (event) {
  let data = event.data;
  if (data.type === "ApriMenuPausa") {
    ApriMenuPausa();

  }
});

function post(path) {
  fetch(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
    },
    body: JSON.stringify({}),
  }).then((resp) => resp.json());
}

function Mappa() {
    post(`https://krs_menupausa/mappa`)
    document.querySelector(".title").style.display = "none";
    document.querySelector(".boxkaros").style.display = "none";
    document.querySelector(".boxkaros2").style.display = "none";
    document.querySelector(".boxkaros3").style.display = "none";
    document.querySelector(".boxkaros4").style.display = "none";
    document.querySelector(".boxkaros5").style.display = "none";
    document.querySelector(".background").style.display = "none";
}
function Impostazioni() {
    post(`https://krs_menupausa/impostazioni`)
    document.querySelector(".title").style.display = "none";
    document.querySelector(".boxkaros").style.display = "none";
    document.querySelector(".boxkaros2").style.display = "none";
    document.querySelector(".boxkaros3").style.display = "none";
    document.querySelector(".boxkaros4").style.display = "none";
    document.querySelector(".boxkaros5").style.display = "none";
    document.querySelector(".background").style.display = "none";
}
function Disconnetti() {
    post(`https://krs_menupausa/disconnetti`)
    document.querySelector(".title").style.display = "none";
    document.querySelector(".boxkaros").style.display = "none";
    document.querySelector(".boxkaros2").style.display = "none";
    document.querySelector(".boxkaros3").style.display = "none";
    document.querySelector(".boxkaros4").style.display = "none";
    document.querySelector(".boxkaros5").style.display = "none";
    document.querySelector(".background").style.display = "none";
}

function Discord() {
    post(`https://krs_menupausa/discord`)

    console.log("discord aperto");

    window.invokeNative('openUrl', 'https://discord.gg/wM4XDaXfU8')


    document.querySelector(".title").style.display = "none";
    document.querySelector(".boxkaros").style.display = "none";
    document.querySelector(".boxkaros2").style.display = "none";
    document.querySelector(".boxkaros3").style.display = "none";
    document.querySelector(".boxkaros4").style.display = "none";
    document.querySelector(".boxkaros5").style.display = "none";
    document.querySelector(".background").style.display = "none";
}


const playerJob = document.getElementById("job")
const playerCash = document.getElementById("cash")
const playerBank = document.getElementById("bank")
const playerName = document.getElementById("nome")


window.addEventListener('message', (event) => {
  
    if (event.data.action === 'open') {
        playerJob.innerHTML  = Lang.job.replace("%s", event.data.job)
        playerCash.innerHTML  = `${Lang.cash} ${event.data.cash}`
        playerBank.innerHTML  = `${Lang.bank} ${event.data.bank}`
        playerName.innerHTML = event.data.name;
    } else if(event.data.action === 'updateJob') {
      playerJob.innerHTML  = Lang.job.replace("%s", event.data.job.label)
    } else if(event.data.action === 'setLang') {
      Lang = event.data.lang
      document.getElementsByClassName("title")[0].innerHTML = Lang.titolo
      document.getElementsByClassName("title2")[0].innerHTML = Lang.mappa
      document.getElementsByClassName("title2")[1].innerHTML = Lang.impostazioni
      document.getElementsByClassName("title2")[2].innerHTML = Lang.disconnetti
      document.getElementsByClassName("title2")[3].innerHTML = Lang.info
    }
});




//Funzione Close
document.onkeydown = function (evt) {
  evt = evt || window.event;
  var isEscape = false;
  if ("key" in evt) {
    isEscape = evt.key === "Escape" || evt.key === "Esc";
  } else {
    isEscape = evt.keyCode === 27;
  }
  if (isEscape) {
    
    post(`https://${GetParentResourceName()}/close`);
      
    document.querySelector(".title").style.display = "none";
    document.querySelector(".boxkaros").style.display = "none";
    document.querySelector(".boxkaros2").style.display = "none";
    document.querySelector(".boxkaros3").style.display = "none";
    document.querySelector(".boxkaros4").style.display = "none";
    document.querySelector(".boxkaros5").style.display = "none";
    document.querySelector(".background").style.display = "none";
  }
};



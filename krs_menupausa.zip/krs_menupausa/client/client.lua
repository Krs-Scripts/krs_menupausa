local PlayerData = {}
local pauseMenuOpen = false

Citizen.CreateThread(function()
   while not ESX.IsPlayerLoaded() do 
	Wait(0)
   end
   PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer
	ESX.PlayerLoaded = true
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    PlayerData.job = job
	SendNUIMessage({
		action = 'updateJob',
		job = job
	})
end)

RegisterKeyMapping('menupausa', 'MENU PAUSA', 'KEYBOARD', 'ESCAPE')


RegisterCommand('menupausa',function()
		if not IsPauseMenuActive() then
			ApriMenuPausa()
		TriggerScreenblurFadeIn(0)
	end
end)

CreateThread(function()
	while true do
		Wait(0)
		DisableControlAction(1, 200, true)
		 if IsPauseMenuActive() then 
			TriggerScreenblurFadeOut(0)
		 end
	end
end)


RegisterNUICallback('close', function(data, cb)
	TriggerScreenblurFadeOut(0)
	SetNuiFocus(false,false)
	 cb('ok')
end)
 

RegisterNUICallback('mappa', function(data,cb)
	ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_MP_PAUSE'), 0, -1)
    SetNuiFocus(false, false)
	pauseMenuOpen = false
	cb('ok')
 end)

RegisterNUICallback('impostazioni', function(data,cb)
    ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_LANDING_MENU'), 0, -1)
    SetNuiFocus(false, false)
	pauseMenuOpen = false
	cb('ok')
 end)

RegisterNUICallback('disconnetti', function(data,cb)
    TriggerServerEvent("krs_pausemenu:escidalgioco")
    SetNuiFocus(false, false)
	pauseMenuOpen = false
	cb('ok')
end)

RegisterNUICallback('discord', function(data,cb)
    SetNuiFocus(false, false)
	pauseMenuOpen = false
	cb('ok')
end)


function ApriMenuPausa()
	if not pauseMenuOpen then
		
		SendNUIMessage({
			action = "setLang",
			lang = Config.Lang
		})
		
		local playerJob = PlayerData.job.label
		local playerCash = getAccount('money')
		local playerBank = getAccount('bank')

		local playerName = PlayerData.firstName .. ' ' .. PlayerData.lastName

		pauseMenuOpen = true
		SetNuiFocus(true, true)
		SendNUIMessage({
			action = 'open',

			job = playerJob,
			cash = playerCash,
			bank = playerBank,
			name = playerName,
		})

		SendNUIMessage({
			type = "ApriMenuPausa",
		   
		  })
		  SetNuiFocus(true, true)
	end
	pauseMenuOpen = not pauseMenuOpen
end

getAccount = function(type)
	local accounts = PlayerData.accounts 
	for k,v in pairs(accounts) do 
		if type == v.name then 
			return v.money
		end
	end
	return 0
end